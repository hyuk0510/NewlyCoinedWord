//
//  SampleViewController.swift
//  NewlyCoinedWord
//
//  Created by 선상혁 on 2023/07/21.
//

import UIKit

class SampleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    

}
